#include<unistd.h>
#include "rush1-3/rush.c"

void my_putchar(char c)
{
    write(1, &c , 1);
}

int main(int argc, char **argv)
{
    rush(4,4);
}