/*
** EPITECH PROJECT, 2019
** CPool_evalexpr_2019
** File description:
** eval_expr
*/

typedef struct pile
{
    char *val[100];
    int top;
} pile_t;

typedef struct list
{
    char *val;
    struct list *next;
    struct list *pre;
} list_t;

int eval_expr(char const *str );
void my_putchar(char c);
int	my_put_nbr(int nb);
int len(char *str);
pile_t *init(void);
void push(pile_t *p, char *val);
void pop(pile_t *p, char *val);
int is_empty(pile_t *p);
list_t *init_list(char *val);
list_t *add_to_end(list_t *l1, list_t *l2);
int test_parenthesis(char *str);
int test_allowed_char(char *str);
int test_operator_parenthesis(char *str);
int cases(char c);
list_t *calcul(list_t *l);
list_t *delet_node(list_t *l1, list_t *l2);
int	my_getnbr(char *str);
list_t *getfirst(list_t *l);
int my_putstr(char const *str);
char *tos(int val, char *res);
int getlen_int (int val);