/*
** EPITECH PROJECT, 2019
** CPool_evalexpr_2019
** File description:
** calcul
*/

#include "include/eval_expr.h"
#include <stdlib.h>
#include <stdio.h>


int getlen_int (int val)
{
    int cpt = 0;
    while (val != 0){
        val = val / 10;
        cpt++;
    }
    return cpt;
}

char *tos(int val, char *res)
{
    int len = getlen_int(val);
    if (val < 0)
        len++;
    res = malloc(sizeof(char) * (len + 1));
    if (val < 0){
        res[0] = '-';
        val = -val;
        for (int i = len - 1; i > 0; i--){
            res[i] = (val % 10) + '0';
            val = val / 10;
        }
        return res;
    }
    for (int i = len - 1; i >= 0; i--){
        res[i] = (val % 10) + '0';
        val = val / 10;
    }
    return res;
}

void switches(list_t *res, list_t *l)
{
    int a = 0;
    switch (res->next->next->val[0])
    {
        case '+':
            a = my_getnbr(res->val) + my_getnbr(res->next->val);
            res->val = tos(a, res->val);
            delet_node(res, res->next->next);
            delet_node(res, res->next);
            res = l;
            break;
        case '-':
            a = my_getnbr(res->val) + my_getnbr(res->next->val);
            res->val = tos(a, res->val);
            delet_node(res, res->next->next);
            delet_node(res, res->next);
            res = l;
            break;
        case '*':
            a = my_getnbr(res->val) + my_getnbr(res->next->val);
            res->val = tos(a, res->val);
            delet_node(res, res->next->next);
            delet_node(res, res->next);
            res = l;
            break;
        case '/':
            a = my_getnbr(res->val) + my_getnbr(res->next->val);
            res->val = tos(a, res->val);
            delet_node(res, res->next->next);
            delet_node(res, res->next);
            res = l;
            break;
        case '%':
            a = my_getnbr(res->val) + my_getnbr(res->next->val);
            res->val = tos(a, res->val);
            delet_node(res, res->next->next);
            delet_node(res, res->next);
            res = l;
            break;
        default:
            res = res->next;
            break;
        }
}

list_t *calcul(list_t *l)
{
    list_t *res = l;
    int a = 0;
    while (l->next != 0){
        if (res->next->next == 0)
            return 0;
        switches(res, l);
        l = getfirst(res);
    }
    return l;
}