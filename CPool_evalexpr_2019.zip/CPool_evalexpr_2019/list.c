/*
** EPITECH PROJECT, 2019
** list.c
** File description:
** list.c
*/

#include "include/eval_expr.h"
#include <stdlib.h>

list_t *init_list(char *val)
{
    list_t *l = malloc(sizeof(list_t));
    l->val = malloc(sizeof(char) * (len(val) + 1));
    l->val = val;
    l->next = 0;
    l->pre = 0;
    return l;
}

list_t *add_to_end(list_t *l1, list_t *l2)
{
    list_t *tmp = l1;
    while (tmp->next != 0){
        tmp = tmp->next;
    }
    tmp->next = malloc(sizeof(list_t));
    tmp->next = l2;
    l2->pre = tmp;
    return l1;
}

list_t *delet_node(list_t *l1, list_t *l2)
{
    list_t *tmp1 = l1;
    while (tmp1->next != l2 && tmp1->next != 0){
        tmp1 = tmp1->next;
    }
    if (tmp1->next == 0){
        return 0;
    }
    else if (l2->next == 0){
        tmp1->next = 0;
        free(l2);
    } else{
        tmp1->next = l2->next;
        l2->next->pre = tmp1;
        free(l2);
    }
    return l1;
}

list_t *getfirst(list_t *l)
{
    list_t *res = l;
    while (res->pre != 0){
        res = res->pre;
    }
    return res;
}