/*
** EPITECH PROJECT, 2019
** CPool_infinadd_2019
** File description:
** main
*/

#include "include/eval_expr.h"
#include <stdio.h>

int main (int ac , char ** av )
{
    if ( ac == 2) {
        // my_put_nbr ( eval_expr ( av [1]) ) ;
        // my_putchar ('\n') ;
        list_t *l1 = init_list("5");
        list_t *l5 = init_list("4");
        list_t *l2 = init_list("+");
        list_t *l3 = add_to_end(l1, add_to_end(l5, l2));
        int a = my_getnbr(l1->val) + my_getnbr(l5->val);
        char *res;
        res = tos(a, res);
        //printf("%d", getlen_int(a));
        printf( "%c", l3->next->next->val[0]);
        printf( "%s", l3->next->val);
        printf( "%s", l3->val);
        printf( "%s", calcul(l3)->val);
        return (0) ;
    }
    return (84) ;
}