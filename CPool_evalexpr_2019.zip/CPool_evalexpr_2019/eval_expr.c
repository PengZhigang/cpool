/*
** EPITECH PROJECT, 2019
** CPool_evalexpr_2019
** File description:
** eval_expr
*/

#include "include/eval_expr.h"
#include <stdlib.h>

int prority(char c)
{
    if (c == '+' || c == '-')
        return 0;
    if (c == '%' || c == '/' || c == '+' )
        return 1;
}

int cases(char c)
{
    if (c == '+' || c == '-' || c == '%' || c == '/' || c == '+' )
        return 1;
    if (c <= '9' && c >= '0')
        return 2;
    if (c == '(')
        return 3;
    if (c == ')')
        return 4;
    return 0;
}

char *capture_nbr(char *str, int index)
{
    char *res = malloc(sizeof(char) * len(str));
    int j = 0;
    for (int i = index; i < len(str); i++) {
        if (cases(str[i] == 2)){
            res[j] == str[i];
            j++;
        } else
            break;
    }
    return res;
}

int eval_expr(char const *str )
{
    int i = 0;
    char *s = (char *) str;
    list_t *l = init_list(s);
    pile_t *p = init();
    while (str[i] != '\0') {

    }
}