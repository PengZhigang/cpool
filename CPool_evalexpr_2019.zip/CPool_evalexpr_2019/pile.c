/*
** EPITECH PROJECT, 2019
** CPool_evalexpr_2019
** File description:
** pile
*/

#include "include/eval_expr.h"
#include <stdlib.h>

pile_t *init(void)
{
    pile_t *p = malloc(sizeof(pile_t));
    p->top = 0;
    return p;
}

void push(pile_t *p, char *val)
{
    p->top++;
    p->val[p->top] = malloc(sizeof(char) * (len(val) + 1));
    p->val[p->top] = val;
}

void pop(pile_t *p, char *val)
{
    if (p->top == 0){
        return;
    }
    else{
        val = p->val[p->top];
        free(p->val[p->top]);
        p->top--;
    }
}

int is_empty(pile_t *p)
{
    if (p->top == 0)
        return 1;
    return 0;
}