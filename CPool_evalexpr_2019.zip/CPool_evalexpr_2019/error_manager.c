/*
** EPITECH PROJECT, 2019
** CPool_evalexpr_2019
** File description:
** gestion_erreur
*/

#include "include/eval_expr.h"

int test_parenthesis(char *str)
{
    int open_parenthesis = 0;
    int close_parenthesis = 0;

    for (int i = 0; i < len(str); ++i) {
        if (str[i] == '(')
            ++open_parenthesis;
        else if (str[i] == ')')
            ++close_parenthesis;
    }
    if (open_parenthesis != close_parenthesis)
        return 0;
    return 1;
}

int test_allowed_char(char *str)
{
    char c;
    int count;

    for (int i = 0; i < len(str); ++i) {
        count = 0;
        c = str[i];
        if (cases(c) != 1 && c != '(' && c != ')')
            ++count;
        if (c < '0' || c > '9')
            ++count;
        if (2 == count)
            return 0;
    }
    return 1;
}

int test_operator_parenthesis(char *str)
{
    char c;
    char c1;
    char c2;
    for (int i = 0; i < len(str); ++i) {
        c = str[i];
        c1 = str[i + 1];
        c2 = str[i - 1];
        if (c == '(' && (c2 >= '0' && c2 <= '9') && i != 0)
            return 0;
        if (c == ')' && cases(c2) == 1 && i != 0)
            return 0;
        if (c == ')' && (c1 >= '0' && c1 <= '9') && i != len(str) -1)
            return 0;
        if (c == '(' && cases(c1) == 1 && i != len(str) -1 )
            return 0;
    }
    return 1;
}