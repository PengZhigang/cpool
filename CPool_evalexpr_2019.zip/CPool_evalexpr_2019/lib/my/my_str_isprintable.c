/*
** EPITECH PROJECT, 2019
** CPool_Day13_2019
** File description:
** my_str_isprintable
*/

int	my_str_isprintable(char *str)
{

}
