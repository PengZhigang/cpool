/*
** EPITECH PROJECT, 2019
** CPool_Day13_2019
** File description:
** my_strlcat
*/

int	my_strlcat(char *dest, char *src, int size)
{

}
