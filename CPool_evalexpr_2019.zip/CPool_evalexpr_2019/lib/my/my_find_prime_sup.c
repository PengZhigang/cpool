/*
** EPITECH PROJECT, 2019
** CPool_Day13_2019
** File description:
** my_find_prime_sup
*/

int	my_find_prime_sup(int nb)
{

}
