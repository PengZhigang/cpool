/*
** EPITECH PROJECT, 2019
** CPool_Day13_2019
** File description:
** my_showstr
*/

int	my_showstr(char *str)
{

}
