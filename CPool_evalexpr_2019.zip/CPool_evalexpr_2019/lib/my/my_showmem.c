/*
** EPITECH PROJECT, 2019
** CPool_Day13_2019
** File description:
** my_showmem
*/

int	my_showmem(char *str, int size)
{

}
